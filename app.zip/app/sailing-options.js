"use strict";
var SailingOption = (function () {
    function SailingOption() {
    }
    return SailingOption;
}());
exports.SailingOption = SailingOption;
//# sourceMappingURL=sailing-options.js.map