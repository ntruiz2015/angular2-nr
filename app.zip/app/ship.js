"use strict";
var Ship = (function () {
    function Ship() {
    }
    return Ship;
}());
exports.Ship = Ship;
//# sourceMappingURL=ship.js.map