"use strict";
var Sailing = (function () {
    function Sailing() {
    }
    return Sailing;
}());
exports.Sailing = Sailing;
//# sourceMappingURL=sailings.js.map