"use strict";
var CruiseLine = (function () {
    function CruiseLine() {
    }
    return CruiseLine;
}());
exports.CruiseLine = CruiseLine;
//# sourceMappingURL=cruise-line.js.map