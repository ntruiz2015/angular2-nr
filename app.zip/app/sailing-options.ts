export class SailingOption {
    sailing_price: number;
    sailing_date: string;
}