"use strict";
var Serialize = (function () {
    function Serialize() {
    }
    Serialize.prototype.fillFromJson = function (json) {
        var obj = JSON.parse(json);
        for (var propName in obj) {
            this[propName] = obj[propName];
        }
        return obj;
    };
    return Serialize;
}());
exports.Serialize = Serialize;
//# sourceMappingURL=serialize.js.map