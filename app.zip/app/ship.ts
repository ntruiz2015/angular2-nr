import { CruiseLine } from './cruise-line';
import { Sailing } from './sailings';

export class Ship {
    salings: Sailing [];
    cruiseLines: CruiseLine[];
}