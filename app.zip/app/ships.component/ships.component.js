"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var sailing_service_1 = require('./sailing.service');
var ships_detail_component_1 = require('../ships-detail.component/ships-detail.component');
var ShipsComponent = (function () {
    function ShipsComponent(sailingService) {
        this.sailingService = sailingService;
        this.ships = [];
        this.sailings = [];
        this.cruiseLines = [];
        this.selectedTotal = 0;
    }
    ;
    ShipsComponent.prototype.ngOnInit = function () {
        this.getSailingsCruiseLines();
    };
    ShipsComponent.prototype.getSailingsCruiseLines = function () {
        var _this = this;
        this.sailingService.getSailingsCruiseLines()
            .subscribe(function (result) {
            _this.ships = result;
            _this.sailings = result.sailings;
            _this.cruiseLines = result.cruise_lines;
            _this.cruiseLines = _this.cruiseLines.map(function (cruiseLine) {
                cruiseLine.sailing = _this.matchSailing(cruiseLine.cruise_line_id);
                return cruiseLine;
            });
        }, function (error) { return _this.errorMessage = error; });
    };
    ShipsComponent.prototype.matchSailing = function (cruiseLineId) {
        var matched = this.sailings.find(function (sailing) { return sailing.sailing_cruise_line_id === cruiseLineId; });
        return matched;
    };
    ShipsComponent.prototype.updatedSelectedTotal = function (selectedOptionPrice) {
        var totalSelected = 0;
        this.shipsDetailComponent.forEach(function (component) {
            totalSelected += component.selectedOptionPrice;
        });
        this.selectedTotal = totalSelected;
    };
    __decorate([
        core_1.ViewChildren(ships_detail_component_1.ShipsDetailComponent), 
        __metadata('design:type', core_1.QueryList)
    ], ShipsComponent.prototype, "shipsDetailComponent", void 0);
    ShipsComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'ships-component',
            templateUrl: 'ships.component.html'
        }), 
        __metadata('design:paramtypes', [sailing_service_1.SailingService])
    ], ShipsComponent);
    return ShipsComponent;
}());
exports.ShipsComponent = ShipsComponent;
//# sourceMappingURL=ships.component.js.map